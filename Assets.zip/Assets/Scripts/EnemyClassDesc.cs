using UnityEngine;

public class EnemyClassDesc : CharacterClass
{
    public int damage;
    public WeaponClass lootReward;
}
